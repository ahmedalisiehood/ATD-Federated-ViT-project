# Federated Vision Transformer Project

This repository implements a decentralized Vision Transformer (ViT) for multi-modal medical imaging (CT, PET, X-ray).

## Features
- Multi-head ViT architecture for modality-specific learning.
- Grad-CAM visualization for interpretability.
- t-SNE visualization for feature space analysis.
- Preprocessing pipelines for CT (DICOM), PET (DICOM), and X-ray (JPG).

## Installation
1. Clone the repository:
   ```bash
   git clone https://github.com/username/federated_vit_project.git
   cd federated_vit_project
