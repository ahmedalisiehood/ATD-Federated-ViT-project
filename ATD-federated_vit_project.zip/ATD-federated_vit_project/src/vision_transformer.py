import torch
import torch.nn as nn

class VisionTransformer(nn.Module):
    def __init__(self, image_size, patch_size, num_heads, num_classes, embed_dim, num_layers):
        super(VisionTransformer, self).__init__()
        self.patch_embed = nn.Conv2d(1, embed_dim, kernel_size=patch_size, stride=patch_size)
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.pos_embed = nn.Parameter(torch.zeros(1, (image_size // patch_size) ** 2 + 1, embed_dim))
        self.encoder = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(embed_dim, nhead=num_heads),
            num_layers=num_layers
        )
        self.heads = nn.ModuleList([nn.Linear(embed_dim, num_classes) for _ in range(num_heads)])

    def forward(self, x):
        x = self.patch_embed(x).flatten(2).transpose(1, 2)
        cls_tokens = self.cls_token.expand(x.size(0), -1, -1)
        x = torch.cat((cls_tokens, x), dim=1) + self.pos_embed
        x = self.encoder(x)
        return [head(x[:, 0]) for head in self.heads]
