import torch
from torch.utils.data import Dataset, DataLoader
from preprocessing import preprocess_image

class MedicalDataset(Dataset):
    def __init__(self, file_paths, labels, modality, target_size=(224, 224)):
        self.file_paths = file_paths
        self.labels = labels
        self.modality = modality
        self.target_size = target_size

    def __len__(self):
        return len(self.file_paths)

    def __getitem__(self, idx):
        file_path = self.file_paths[idx]
        label = self.labels[idx]
        image = preprocess_image(file_path, self.modality, self.target_size)
        image = torch.tensor(image, dtype=torch.float32).unsqueeze(0)
        return image, label

def get_dataloader(file_paths, labels, modality, batch_size=32, target_size=(224, 224)):
    dataset = MedicalDataset(file_paths, labels, modality, target_size)
    return DataLoader(dataset, batch_size=batch_size, shuffle=True)
