import torch
import numpy as np
import matplotlib.pyplot as plt
import cv2

def compute_gradcam(model, images, head_idx, class_idx, device):
    model.eval()
    images = images.to(device)
    images.requires_grad = True

    outputs = model(images)[head_idx]
    one_hot = torch.zeros_like(outputs)
    one_hot[:, class_idx] = 1

    outputs.backward(gradient=one_hot)
    gradients = images.grad
    pooled_gradients = gradients.mean(dim=(2, 3), keepdim=True)

    features = model.patch_embed(images).detach().cpu().numpy()
    pooled_gradients = pooled_gradients.detach().cpu().numpy()

    heatmap = np.sum(pooled_gradients * features, axis=1)
    heatmap = np.maximum(heatmap, 0)
    heatmap = (heatmap - np.min(heatmap)) / (np.max(heatmap) + 1e-8)
    return heatmap

def visualize_gradcam(image, heatmap, save_path=None):
    heatmap = cv2.resize(heatmap, (image.shape[1], image.shape[0]))
    heatmap = np.uint8(255 * heatmap)
    heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
    overlay = cv2.addWeighted(heatmap, 0.5, image, 0.5, 0)
    plt.imshow(overlay)
    plt.axis('off')
    if save_path:
        plt.savefig(save_path, bbox_inches='tight')
    plt.show()
