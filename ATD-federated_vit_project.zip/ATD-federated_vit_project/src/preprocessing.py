import pydicom
import cv2
import numpy as np
from PIL import Image

def preprocess_ct(file_path, target_size=(224, 224)):
    dicom_file = pydicom.dcmread(file_path)
    image = dicom_file.pixel_array
    image = (image - np.min(image)) / (np.max(image) - np.min(image))
    image = cv2.resize(image, target_size)
    return image

def preprocess_pet(file_path, target_size=(224, 224)):
    dicom_file = pydicom.dcmread(file_path)
    image = dicom_file.pixel_array
    image = (image - np.min(image)) / (np.max(image) - np.min(image))
    image = cv2.resize(image, target_size)
    return image

def preprocess_xray(file_path, target_size=(224, 224)):
    image = Image.open(file_path).convert("L")
    image = image.resize(target_size)
    image = np.array(image) / 255.0
    return image

def preprocess_image(file_path, modality, target_size=(224, 224)):
    if modality == 'CT':
        return preprocess_ct(file_path, target_size)
    elif modality == 'PET':
        return preprocess_pet(file_path, target_size)
    elif modality == 'X-ray':
        return preprocess_xray(file_path, target_size)
    else:
        raise ValueError(f"Unsupported modality: {modality}")
