import matplotlib.pyplot as plt
from sklearn.manifold import TSNE

def compute_tsne(features, labels, perplexity=30, n_components=2, random_state=42):
    tsne = TSNE(n_components=n_components, perplexity=perplexity, random_state=random_state)
    embeddings = tsne.fit_transform(features)
    return embeddings

def visualize_tsne(embeddings, labels, classes, save_path=None):
    plt.figure(figsize=(8, 8))
    scatter = plt.scatter(embeddings[:, 0], embeddings[:, 1], c=labels, cmap="viridis", alpha=0.7)
    plt.colorbar(scatter, ticks=range(len(classes)), label="Class")
    plt.title("t-SNE Visualization")
    if save_path:
        plt.savefig(save_path, bbox_inches='tight')
    plt.show()
